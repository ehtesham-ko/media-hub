CREATE POLICY "Authenticated can read assets bucket" ON storage.objects
  FOR SELECT TO authenticated USING (bucket_id = 'assets');
CREATE POLICY "Authenticated can upload to assets bucket" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'assets');
CREATE POLICY "Authenticated can update assets bucket" ON storage.objects
  FOR UPDATE TO authenticated USING (bucket_id = 'assets');
CREATE POLICY "Authenticated can delete from assets bucket" ON storage.objects
  FOR DELETE TO authenticated USING (bucket_id = 'assets');
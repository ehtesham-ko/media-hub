import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listUsers, setUserActive, setUserRole } from "@/lib/users.functions";
import { ROLES } from "@/lib/permissions";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/users")({
  head: () => ({ meta: [{ title: "Users | Asset Library" }] }),
  component: UsersPage,
});

function UsersPage() {
  const listFn = useServerFn(listUsers);
  const activeFn = useServerFn(setUserActive);
  const roleFn = useServerFn(setUserRole);
  const qc = useQueryClient();

  const { data, isLoading, error } = useQuery({ queryKey: ["users"], queryFn: () => listFn() });

  const activeMut = useMutation({
    mutationFn: (v: { userId: string; is_active: boolean }) => activeFn({ data: v }),
    onSuccess: () => { toast.success("User updated"); qc.invalidateQueries({ queryKey: ["users"] }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const roleMut = useMutation({
    mutationFn: (v: { userId: string; role: "Admin" | "Journalist" | "Editor" }) => roleFn({ data: v }),
    onSuccess: () => { toast.success("Role updated"); qc.invalidateQueries({ queryKey: ["users"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-serif text-2xl font-bold text-foreground">Users</h1>
        <p className="text-sm text-muted-foreground">Manage roles and account status.</p>
      </div>
      {error && <p className="text-sm text-destructive">{(error as Error).message}</p>}
      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="hidden px-4 py-3 md:table-cell">Email</th>
              <th className="px-4 py-3">Role</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {isLoading && <tr><td colSpan={4} className="px-4 py-8 text-center text-muted-foreground">Loading…</td></tr>}
            {data?.users.map((u) => (
              <tr key={u.id}>
                <td className="px-4 py-3 font-medium text-foreground">{u.name}</td>
                <td className="hidden px-4 py-3 text-muted-foreground md:table-cell">{u.email}</td>
                <td className="px-4 py-3">
                  <select
                    value={u.role}
                    onChange={(e) => roleMut.mutate({ userId: u.id, role: e.target.value as "Admin" | "Journalist" | "Editor" })}
                    className="rounded-md border border-input bg-background px-2 py-1 text-sm"
                  >
                    {ROLES.map((r) => <option key={r}>{r}</option>)}
                  </select>
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => activeMut.mutate({ userId: u.id, is_active: !u.is_active })}
                    className={`rounded-full px-2 py-0.5 text-xs font-medium ${u.is_active ? "bg-[oklch(0.55_0.09_145)]/15 text-[oklch(0.42_0.09_145)]" : "bg-muted text-muted-foreground"}`}
                  >
                    {u.is_active ? "Active" : "Inactive"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}